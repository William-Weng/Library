#import <Foundation/Foundation.h>

@protocol LSHTTPBody <NSObject>
- (NSData *)data;
@end
