import Vue from "vue"
import VueRx from "vue-rx"

Vue.use(VueRx)
