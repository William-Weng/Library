# MIDDLEWARE
<br/>
parsedefaulturl.js - parse default url for appropriate path  
<br/>
<br/>

More information about the usage of this directory in [the documentation](https://nuxtjs.org/guide/routing#middleware).
