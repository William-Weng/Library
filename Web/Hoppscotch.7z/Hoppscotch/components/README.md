# COMPONENTS

The components directory contains your Vue.js Components.

_Nuxt.js doesn't supercharge these components._
